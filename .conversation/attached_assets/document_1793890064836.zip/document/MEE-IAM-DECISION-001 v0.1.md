# MEE-IAM-DECISION-001
## AC-18 to AC-21 Architecture & Data Governance Decision Record

| Field | Value |
| --- | --- |
| Document ID | MEE-IAM-DECISION-001 |
| Version | 0.1 |
| Status | DRAFT — PENDING REVIEW |
| Decision Status | NOT DECIDED |
| Date | 2026-11-05 |
| Related Document | MEE-IAM-DATA-001 v0.5 |
| Baseline | MEE-IAM-DATA-001 v0.4 |
| Scope | Logical Data Model and Governance Decisions |

---

## 1. Purpose

เอกสารนี้จัดทำขึ้นเพื่อรวบรวมประเด็นที่ต้องตัดสินใจจาก AC-18 ถึง AC-21 ก่อนนำข้อกำหนดไปใช้เป็นมาตรฐานใน Data Model, Integration Specification หรือ Architecture Specification

หลักการ:

1. ไม่แก้ไขหรือเขียนทับ MEE-IAM-DATA-001 v0.4
2. ไม่ถือว่า AC-18 ถึง AC-21 ได้รับอนุมัติแล้ว
3. แยกข้อเสนอแนะออกจากมติที่ได้รับอนุมัติ
4. ทุกการตัดสินใจต้องมีเหตุผล ผลกระทบ และผู้มีอำนาจอนุมัติ
5. ไม่มีการอนุญาตให้ดำเนินการ Implementation จากเอกสารนี้

### 1.1 Decision Review Order

ให้พิจารณา Decision ตามลำดับต่อไปนี้:

1. **D-018 — Event Ordering:** มีผลต่อการออกแบบ Event และ Audit ทั้งระบบ
2. **D-019 — Correction:** มีผลต่อการสร้างประวัติที่ถูกต้อง
3. **D-020 — Policy/Gate Version:** เป็นฐานของอำนาจอนุมัติ
4. **D-021 — Identity Mapping:** เชื่อมโยงกับ Integration และ Clerk

ลำดับนี้เป็นลำดับการวิเคราะห์ ไม่ใช่การเลือกหรืออนุมัติตัวเลือกใดล่วงหน้า ตัวเลือกที่แนะนำในเอกสารนี้—including Option C—เป็นข้อเสนอเพื่อพิจารณาเท่านั้น ระบบต้องไม่ถือว่าเป็นค่าเริ่มต้นหรือเปลี่ยนพฤติกรรมตามตัวเลือกนั้น จนกว่าจะมีการเลือกและอนุมัติโดยผู้มีอำนาจ

---

## 2. Decision D-018 — Event Ordering Scope and Sequence Location

**Related AC:** AC-18  
**Status:** OPEN — PENDING DECISION

### 2.1 Problem

Data Model ต้องกำหนดตำแหน่งและขอบเขตของลำดับเหตุการณ์ให้ชัดเจน เพื่อให้สามารถสร้างประวัติย้อนหลังได้อย่าง deterministic

ประเด็นที่ยังไม่ตัดสิน:

- Sequence อยู่ใน `domain_event_envelopes` หรือ Event Stream แยกต่างหาก
- Sequence มีขอบเขตระดับใด
- การเปรียบเทียบ Event ข้าม Aggregate หรือ Gate ใช้กติกาใด
- การเรียง Event ที่มี Timestamp เท่ากันทำอย่างไร

ข้อเท็จจริงจาก v0.4 ที่ต้องรักษาไว้ระหว่างพิจารณา: `domain_event_envelopes` มี `domain_event_id` และ temporal/correction metadata แต่ไม่มี sequence field ในรายการ field; กติกาปัจจุบันกำหนดให้แต่ละ event-sourced entity ระบุ sequence scope และ tie-breaker ของตนเอง

### 2.2 Options

#### Option A — Aggregate-scoped sequence

กำหนด Sequence ภายใน Aggregate แต่ละรายการ

**ข้อดี:**

- ลดการบังคับให้ทุก Event ใช้ลำดับส่วนกลาง
- เหมาะกับการสร้างประวัติของ Entity หรือ Aggregate

**ข้อจำกัด:**

- ไม่สามารถนำ Sequence ต่าง Aggregate มาเปรียบเทียบกันโดยตรง

#### Option B — Global sequence

กำหนด Sequence ระดับระบบ

**ข้อดี:**

- มีลำดับรวมที่ชัดเจน

**ข้อจำกัด:**

- ต้องมีผู้จัดสรรลำดับส่วนกลาง
- เพิ่มความซับซ้อนด้าน concurrency และการกู้คืนข้อมูล

#### Option C — Scoped event streams

กำหนด Stream ID และ Sequence ภายในแต่ละ Stream โดย Domain Event อ้างอิง Stream ที่เกี่ยวข้อง

**ข้อดี:**

- กำหนดขอบเขตได้ยืดหยุ่น
- ไม่ต้องบังคับ Global Sequence
- รองรับหลาย Aggregate

**ข้อจำกัด:**

- ต้องกำหนดกติกาการเชื่อมโยงและการเรียงข้าม Stream เพิ่มเติม

### 2.3 Recommendation

เสนอให้พิจารณา Option C เป็นหนึ่งในทางเลือก โดยอาจใช้ `domain_event_envelopes` เป็นจุดอ้างอิง Event Identity และ Ordering Context หากผลการทบทวนยืนยันว่าเหมาะสม Option C ยังไม่ใช่ข้อสรุป ค่าเริ่มต้น หรือกติกาที่ระบบต้องนำไปใช้

ยังไม่กำหนดชื่อตารางหรือ Field เพิ่มเติมจนกว่าจะตรวจสอบ Architecture และ Data Model ร่วมกัน การแสดงลำดับข้าม scope ต้องไม่ถูกตีความเป็น causal order หรือใช้ตัดสินผล conflict โดยปริยาย

### 2.3.1 Impact Assessment for Review — Non-binding

ข้อเท็จจริงจาก v0.4 ที่ใช้ประกอบการพิจารณา:

- `domain_event_envelopes` มี `domain_event_id`, event target, `effective_at_utc`, `recorded_at_utc`, correction metadata, `correlation_id` และ `audit_required` แต่ไม่มี sequence field
- Event-specific records หลายประเภทมี `event_sequence`; v0.4 กำหนดให้ sequence มีขอบเขตใน Event Stream แต่ยังไม่ได้กำหนดว่า Aggregate คืออะไร หรือ Event ใดอยู่ใน Aggregate/Stream เดียวกัน
- `audit_events` มี `domain_event_id` เป็น FK ที่ unique และมี `event_sequence`; v0.4 กำหนดความสัมพันธ์ Domain Event → หนึ่ง event-specific record → หนึ่ง Audit Event แต่ยังไม่ระบุชัดว่า `audit_events.event_sequence` ต้องเท่ากับ sequence ใด หรือเป็นลำดับคนละ scope
- Temporal reconstruction ใช้ `effective_at_utc` แล้วใช้ immutable event sequence เป็น tie-break สำหรับเวลาเดียวกัน; แต่ละ event-sourced entity ต้องกำหนด reducer, sequence scope และ tie-breaking behavior

| Area | ผลกระทบที่ต้องตรวจ |
| --- | --- |
| `domain_event_envelopes` | หากเพิ่ม sequence หรือ stream reference ต้องกำหนดว่าเป็นค่าลำดับอ้างอิงหลักหรือเพียง metadata และทำอย่างไรให้ตรงกับ event-specific record โดยไม่ทำให้ `domain_event_id` สูญเสียบทบาทเป็น Event Identity |
| Aggregate / Event Stream | v0.4 ไม่ได้กำหนด Aggregate root หรือ membership; Option A จึงต้องนิยาม Aggregate และการจัด Event เข้า Aggregate ให้ตรวจสอบได้ ส่วน Option C ต้องนิยาม Stream identity, ขอบเขต, lifecycle และความสัมพันธ์กับ Entity/Aggregate โดยยังไม่ควรสมมติว่าเป็นโครงสร้างที่มีอยู่แล้ว |
| Event-specific records | ต้องกำหนดขอบเขต uniqueness/monotonicity ของ `event_sequence`, การจัดการ concurrency, gaps, retries และการ tie-break เมื่อ `effective_at_utc` เท่ากัน |
| Audit History | ต้องกำหนดว่า `audit_events.event_sequence` เป็น sequence เดียวกับ event-specific record, เป็น snapshot copy ที่ต้องตรวจความตรงกัน หรือเป็น audit-local order; ค่าใน Audit ต้องไม่สร้าง global causal order โดยไม่มีข้อกำหนดรองรับ |
| Temporal reconstruction | ต้องรักษาผลลัพธ์ `T_known` และ `T_effective` ตาม history ที่ยอมรับ และห้ามใช้ timestamp อย่างเดียว, insert order หรือ sequence จากคนละ scope เป็นกฎตัดสิน |
| Corrections | การจัดลำดับ correction ต้องใช้ scope ที่ได้รับอนุมัติ; ลำดับ sequence อย่างเดียวต้องไม่แก้ความขัดแย้งเชิงความหมายหรือแทนมติของผู้มีอำนาจ |

คำถามที่ต้องปิดก่อนเลือก Option:

1. “Aggregate” ในขอบเขต IAM หมายถึงอะไร และต่างจาก event-sourced entity หรือ Gate instance อย่างไร
2. ลำดับ authoritative อยู่ใน event-specific record, `domain_event_envelopes` หรือ Entity แยกสำหรับ Event Stream
3. `audit_events.event_sequence` ต้องสะท้อนลำดับใด และจะบังคับความสอดคล้องกับ Domain Event/event-specific record อย่างไร
4. Sequence ต้อง monotonic และ unique ใน scope ใด; อนุญาต gaps หรือไม่; จัดการ concurrent writes, retry และ recovery อย่างไร
5. Event คนละ scope ที่มี timestamp เดียวกันจะแสดงผลอย่าง deterministic อย่างไร โดยไม่อ้างว่าเป็น causal order
6. Event ที่มีผลต่อหลาย Entity/Aggregate และ correction ที่อ้างข้าม scope จะอยู่ใน ordering model อย่างไร
7. ต้องมีแนวทาง migration/backfill สำหรับประวัติเดิมหรือไม่ และจะตรวจสอบลำดับที่สร้างย้อนหลังอย่างไร

**ผลการพิจารณา D-018:** ยังไม่มีการเลือก Option; ประเด็นด้านบนเป็นงานวิเคราะห์ก่อนขอมติ ไม่ใช่ข้อกำหนดที่อนุมัติแล้ว

### 2.4 Required Decision

- [ ] Option A
- [ ] Option B
- [ ] Option C
- [ ] Alternative

**Selected option:** Pending  
**Decision rationale:** Pending  
**Rejected alternatives and reasons:** Pending  
**Decision impact:** Pending  
**Approving authority (Principal/role):** Pending  
**Approval Authority Check reference:** Pending  
**Applicable Policy Version:** Pending  
**Decision timestamp:** Pending  
**Related document versions:** Pending

**Decision order:** พิจารณา D-018 ก่อน D-019, D-020 และ D-021; บันทึกมติเฉพาะเมื่อผู้มีอำนาจอนุมัติจริง

---

## 3. Decision D-019 — Conflicting Correction Resolution

**Related AC:** AC-19  
**Status:** OPEN — PENDING DECISION

### 3.1 Problem

เมื่อมี Correction หลายรายการอ้างอิง Event เดียวกันและมีผลขัดแย้งกัน ระบบต้องไม่เลือกผลลัพธ์โดยอาศัยลำดับ Insert หรือ Timestamp ที่ไม่ได้กำหนดความหมายไว้

### 3.2 Options

#### Option A — Explicit supersession chain

Correction ใหม่สามารถระบุชัดเจนว่า Supersede Correction เดิม โดยเก็บประวัติทุกเหตุการณ์ไว้

**ข้อดี:**

- ตรวจสอบเส้นทางการแก้ไขได้
- ไม่ต้องลบ Correction เดิม

**ข้อจำกัด:**

- ต้องกำหนดสิทธิ์และเงื่อนไขการ Supersede

#### Option B — Conflict state

เมื่อมี Correction ที่ขัดแย้งกัน ระบบเปลี่ยนสถานะการประมวลผลเป็น `CONFLICT_UNRESOLVED` และไม่สร้าง Effective State ที่ถือว่าเป็นข้อยุติ

**ข้อดี:**

- ไม่เลือกผลลัพธ์โดยพลการ
- เหมาะกับระบบ Evidence และ Governance

**ข้อจำกัด:**

- ต้องมีกระบวนการแก้ไข Conflict แยกต่างหาก

#### Option C — Explicit resolution event

กำหนด Event ใหม่สำหรับตัดสิน Correction ที่ขัดแย้งกัน โดยอ้างอิง Correction ทุกตัวที่เกี่ยวข้อง

**ข้อดี:**

- การตัดสินใจมีหลักฐานและผู้รับผิดชอบ
- แยกการแก้ไขข้อมูลออกจากการตัดสินข้อขัดแย้ง

**ข้อจำกัด:**

- เพิ่ม Entity และ Governance Rules

### 3.3 Recommendation

เสนอแนวทางผสม:

1. ใช้ Explicit Supersession Chain สำหรับการแก้ไขที่มีความสัมพันธ์ชัดเจน
2. ใช้ `CONFLICT_UNRESOLVED` เมื่อมีข้อขัดแย้งที่ยังไม่มีมติ
3. ใช้ Explicit Resolution Event เมื่อจำเป็นต้องมีการตัดสินโดยผู้มีอำนาจ

ห้ามใช้ Last-write-wins เป็นกฎตัดสินโดยปริยาย แนวทางผสมนี้ยังเป็นข้อเสนอ ไม่ใช่มติที่อนุมัติแล้ว

### 3.4 Required Decision

- [ ] Option A
- [ ] Option B
- [ ] Option C
- [ ] Hybrid A+B+C
- [ ] Alternative

**Selected option:** Pending  
**Decision rationale:** Pending  
**Rejected alternatives and reasons:** Pending  
**Decision impact:** Pending  
**Approving authority (Principal/role):** Pending  
**Approval Authority Check reference:** Pending  
**Applicable Policy Version:** Pending  
**Decision timestamp:** Pending  
**Related document versions:** Pending

---

## 4. Decision D-020 — Policy and Gate Version at Sign-off

**Related AC:** AC-20  
**Status:** OPEN — PENDING DECISION

### 4.1 Problem

Authority Check และ Sign-off ต้องอ้างอิง Policy และ Gate Definition ที่เป็นฐานอำนาจในขณะลงนามอย่างชัดเจน

ประเด็นที่ต้องตัดสิน:

- ใช้ Policy Version ณ ตอนเริ่ม Submission หรือ ณ ตอน Sign-off
- ใช้ Gate Definition Version ณ ตอนสร้าง Gate Instance หรือ ณ ตอนตัดสิน
- หากมีการเปลี่ยน Policy ระหว่าง Review จะดำเนินการอย่างไร
- ใครมีอำนาจอนุมัติการเปลี่ยนฐานการประเมิน

v0.4 บันทึก `policy_version` และ Role/Permission Definition Version IDs ใน Authority Check แต่ยังไม่ได้กำหนด immutable Policy Definition หรือ versioned Gate Definition entities การตัดสินนี้จึงต้องระบุทั้งฐานข้อมูลอ้างอิงและวิธีเก็บเนื้อหา/เวอร์ชันที่ใช้จริง

### 4.2 Options

#### Option A — Submission-time baseline

ยึด Policy และ Gate Version ณ เวลาที่สร้าง Submission

**ข้อดี:**

- มีฐานการประเมินที่คงที่ตลอดกระบวนการ
- ลดความเสี่ยงจากการเปลี่ยนกฎระหว่าง Review

**ข้อจำกัด:**

- Policy ใหม่อาจไม่ถูกนำมาใช้กับ Submission ที่ยังไม่เสร็จ

#### Option B — Sign-off-time baseline

ยึด Policy และ Gate Version ที่มีผล ณ เวลาลงนาม

**ข้อดี:**

- สะท้อนกฎที่ใช้อยู่ในขณะตัดสิน

**ข้อจำกัด:**

- อาจทำให้เงื่อนไขการประเมินเปลี่ยนกลางกระบวนการ

#### Option C — Explicit baseline snapshot

กำหนด Policy และ Gate Definition Version เป็น Snapshot Basis ของ Submission หรือ Gate Instance และให้ Authority Check อ้างอิง Snapshot Basis เดียวกัน

หากต้องเปลี่ยน Basis ระหว่างกระบวนการ ต้องมี Event และการอนุมัติแยกต่างหาก

**ข้อดี:**

- มีฐานการประเมินที่ตรวจสอบย้อนหลังได้
- ป้องกันการเปลี่ยนกฎโดยไม่มีหลักฐาน
- แยกการสร้าง Submission ออกจากการอนุมัติการเปลี่ยนฐาน

**ข้อจำกัด:**

- ต้องกำหนดวิธีจัดการ Policy Emergency และ Migration
- ต้องเพิ่มหรือระบุความสัมพันธ์กับ immutable Policy/Gate Definition versions ซึ่งยังไม่มีในโมเดล v0.4

### 4.3 Recommendation

เสนอ Option C

โดยกำหนดให้ Gate Snapshot, Authority Check และ Sign-off อ้างอิง Version Basis ที่สัมพันธ์กันอย่างชัดเจน

หากต้องเปลี่ยน Policy หรือ Gate Basis ต้องมีการบันทึกเหตุผล ผู้อนุมัติ และผลกระทบต่อ Submission ที่เกี่ยวข้อง

### 4.4 Required Decision

- [ ] Option A
- [ ] Option B
- [ ] Option C
- [ ] Alternative

**Selected option:** Pending  
**Decision rationale:** Pending  
**Rejected alternatives and reasons:** Pending  
**Decision impact:** Pending  
**Approving authority (Principal/role):** Pending  
**Approval Authority Check reference:** Pending  
**Applicable Policy Version:** Pending  
**Decision timestamp:** Pending  
**Related document versions:** Pending

---

## 5. Decision D-021 — Identity Mapping Effective-Time Interval

**Related AC:** AC-21  
**Status:** OPEN — PENDING DECISION

### 5.1 Problem

Identity Mapping ต้องสามารถระบุได้ว่า External Identity เชื่อมโยงกับ Principal ใดในช่วงเวลาใด โดยไม่เกิด Active Binding ซ้อนกัน

### 5.2 Proposed Interval Model

เสนอให้พิจารณาช่วงเวลาแบบ Half-open Interval:

`[valid_from_utc, valid_to_utc)`

ความหมาย:

- `valid_from_utc` รวมอยู่ในช่วงเวลา
- `valid_to_utc` ไม่รวมอยู่ในช่วงเวลา
- Mapping เดิมสิ้นสุด ณ เวลาเดียวกับที่ Mapping ใหม่เริ่มได้
- Mapping สองรายการไม่ถือว่าซ้อนกันหากขอบเขตสิ้นสุดและเริ่มต้นตรงกัน

ตัวอย่าง:

- Principal A: `[10:00, 11:00)`
- Principal B: `[11:00, NULL)`

ช่วงเวลาดังกล่าวไม่มีการทับซ้อนกัน

**ข้อจำกัดด้านความสอดคล้อง:** ช่วงเวลาและชื่อฟิลด์ข้างต้นเป็น notation เพื่อพิจารณา ไม่ใช่ field-level guarantee ใน v0.4 โดย `identity_mappings` ใน v0.4 ไม่มี interval fields; ประวัติ lifecycle อยู่ใน `identity_mapping_events` ซึ่งมี `effective_at_utc` และ `recorded_at_utc` ส่วน `valid_from_utc`/`valid_until_utc` ปรากฏใน Entity อื่น การตัดสินต้องระบุว่าจะใช้ Event เป็นแหล่งอำนาจและคำนวณช่วงเวลาเป็น projection หรือจะเพิ่ม interval model รวมถึงต้องตกลงชื่อ end-boundary field ให้ตรงกันก่อนอนุมัติ

### 5.3 Options

#### Option A — Half-open interval

ใช้ `[valid_from_utc, valid_to_utc)` โดย `NULL` หมายถึงไม่มีเวลาสิ้นสุดที่กำหนดไว้

**ข้อดี:**

- จัดการการเปลี่ยน Mapping ได้ตรงขอบเขต
- ลดปัญหาการซ้อนทับที่เวลาเปลี่ยนผ่าน

**ข้อจำกัด:**

- ต้องกำหนดว่า `NULL` หมายถึง Open-ended เท่านั้น หรืออาจหมายถึงยังไม่ทราบ/ข้อมูลไม่สมบูรณ์
- ต้องกำหนดการจัดการ NULL และการแก้ไขย้อนหลัง
- ต้องกำหนดความสัมพันธ์ของ interval กับ authoritative lifecycle events และการบังคับ uniqueness

#### Option B — Explicit lifecycle events only

ใช้ Event เช่น CREATE, SUSPEND, REVOKE และ MIGRATE เป็นหลัก โดยไม่กำหนดช่วงเวลาบน Mapping โดยตรง

**ข้อดี:**

- สอดคล้องกับ Append-only Event Model

**ข้อจำกัด:**

- การ Query ตามเวลาต้อง Replay Lifecycle Events

#### Option C — Hybrid interval and lifecycle events

เก็บ Effective-Time Interval ควบคู่กับ Lifecycle Events เพื่อให้ Query ได้สะดวกและตรวจสอบต้นทางได้ โดยต้องระบุว่า Event History เป็นแหล่งอำนาจ ส่วน interval เป็นข้อมูลที่ derive หรือ materialize จาก Event History หรือไม่

**ข้อดี:**

- รองรับ Temporal Query
- มีประวัติการเปลี่ยนสถานะ

**ข้อจำกัด:**

- ต้องกำหนด Referential Integrity ระหว่าง Interval กับ Lifecycle Events
- ต้องกำหนดวิธีตรวจและซ่อม projection เมื่อไม่ตรงกับ Event History

### 5.4 Recommendation

เสนอ Option C โดยใช้ Half-open Interval เป็นรูปแบบที่ต้องพิจารณา

ข้อกำหนดเพิ่มเติมที่ต้องตัดสิน:

1. `valid_to_utc = NULL` หมายถึง Open-ended หรือไม่ และค่า NULL อื่นใดถือเป็นข้อมูลไม่สมบูรณ์
2. `valid_from_utc` ต้องมีค่าเสมอหรือไม่ และอนุญาตให้เป็นเวลาในอนาคตได้หรือไม่
3. การปิด Mapping ย้อนหลังทำได้ภายใต้เงื่อนไขใด ใครอนุมัติ และต้องอ้างอิง Correction ใด
4. การแก้ไข Effective Time ต้องผ่าน Correction Model อย่างไร โดยต้องเก็บ `recorded_at_utc` เดิมที่ระบบกำหนดและห้าม backdate
5. การเปลี่ยน Principal ต้องไม่ทำให้มี Active Mapping ซ้อนกัน ณ เวลา handoff
6. ต้องแยกเวลาที่ระบบรับรู้ (`T_known`) ออกจากเวลาที่ Mapping มีผล (`T_effective`)
7. หาก lifecycle events หลายรายการมี Effective Timestamp เดียวกัน ต้องใช้ ordering/tie-breaker ที่ตัดสินใน D-018
8. ต้องระบุว่า interval เป็น authoritative data หรือเป็น projection จาก append-only lifecycle events
9. ต้องปรับชื่อ `valid_to_utc` ให้สอดคล้องกับชื่อ field ที่เลือกใน Data Model โดยไม่ถือว่า `valid_until_utc` ของ Entity อื่นเป็น field ของ `identity_mappings`

### 5.5 Required Decision

- [ ] Option A
- [ ] Option B
- [ ] Option C
- [ ] Alternative

**Selected option:** Pending  
**Decision rationale:** Pending  
**Rejected alternatives and reasons:** Pending  
**Decision impact:** Pending  
**Approving authority (Principal/role):** Pending  
**Approval Authority Check reference:** Pending  
**Applicable Policy Version:** Pending  
**Decision timestamp:** Pending  
**Related document versions:** Pending

---

## 6. Cross-document Consistency Requirements

ก่อนนำผลการตัดสินไปปรับเอกสารอื่น ต้องตรวจสอบรายการต่อไปนี้:

| Document | Required consistency |
| --- | --- |
| MEE-IAM-DATA-001 | Entity, Field, FK, Event และ Temporal Model |
| Architecture Specification | Event Ordering, Correction Processing, Snapshot Basis |
| Integration Specification | Identity Key, Mapping Lifecycle, Policy Version |
| Clerk Configuration Record | External Identity Issuer, Subject และ Provider Metadata |
| Evidence-to-Audit Diagram | Domain Event, Event-specific Record, Audit linkage ต้องอิง Entity/FK และ `domain_event_id` ตาม Data Model ไม่ตีความความสัมพันธ์จากลูกศรในภาพเพียงอย่างเดียว |
| MeeChain Operating Center | สถานะ Gate และ Approval Boundary |

### Identity Key Consistency Note

พบความแตกต่างระหว่างเอกสาร:

- Integration Draft: `(provider, issuer, subject)`
- MEE-IAM-DATA-001 v0.4: `(issuer_normalized, subject)`

ข้อเสนอเพื่อทบทวน:

- ยึด `(issuer_normalized, subject)` เป็น Candidate Identity Key ตาม v0.4
- จัดเก็บ `provider` เป็นข้อมูลกำกับ ไม่ใช่ส่วนหนึ่งของ uniqueness key
- รักษา `subject` ตามค่าต้นฉบับ และไม่ใช้ email เป็น identity key
- ตรวจความสอดคล้องในทุกเอกสารก่อนเลือกเป็นมาตรฐานเดียวกัน
- ยังไม่เปลี่ยน Integration Draft จนกว่าจะได้รับการตัดสินและอนุมัติร่วมกัน

---

## 7. Decision Register

| Decision ID | Subject | Current Status | Recommended Option |
| --- | --- | --- | --- |
| D-018 | Event Ordering | OPEN | C |
| D-019 | Correction Conflict | OPEN | Hybrid A+B+C |
| D-020 | Policy/Gate Version Basis | OPEN | C |
| D-021 | Identity Mapping Interval | OPEN | C |

คำว่า Recommended Option แสดงเพียงข้อเสนอเพื่อการพิจารณา ไม่ใช่มติที่อนุมัติแล้ว

---

## 8. Approval and Change Control

การปิด Decision แต่ละรายการต้องบันทึก:

- Decision ID
- Selected Option
- Decision rationale
- Rejected alternatives and reasons
- Approving Principal
- Approval Authority Check reference
- Applicable Policy Version
- Decision timestamp
- Related document versions
- Change impact assessment

การอนุมัติ Decision Record ไม่ได้หมายถึงการอนุมัติ Implementation โดยอัตโนมัติ

---

## 9. Current Governance Boundary

| Item | Status |
| --- | --- |
| MEE-IAM-DATA-001 v0.4 | DRAFT — PENDING REVIEW |
| MEE-IAM-DATA-001 v0.5 | DRAFT — PENDING REVIEW |
| AC-18 to AC-21 | PROPOSED |
| D-018 to D-021 | OPEN — PENDING DECISION |
| Implementation Authorization | NOT GRANTED |
| Gate 1 | NOT STARTED |
| Gate 2 | BLOCKED |
| Gate 3 | NOT STARTED |

**Final Statement:**

MEE-IAM-DECISION-001 v0.1 is a decision-support document only. It does not constitute an approved architecture baseline, a modification to MEE-IAM-DATA-001 v0.4, or authorization to perform implementation or runtime operations.

**Approval Status:** NOT APPROVED
