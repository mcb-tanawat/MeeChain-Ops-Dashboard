MEE-IAM-DATA-001 — Proposed Acceptance Criteria Addendum

Document ID: MEE-IAM-DATA-001
Proposed Version: 0.5
Section: Acceptance Criteria — AC-18 to AC-21
Status: PROPOSED — PENDING CROSS-DOCUMENT REVIEW
Date: 2026-11-05
Basis: User-provided review topics AC-18 to AC-21, checked against MEE-IAM-DATA-001 v0.4 and the related draft documents.

Baseline: MEE-IAM-DATA-001 v0.4 remains DRAFT — PENDING REVIEW and is not modified or superseded by this proposal.

---

Review Boundary

This file is a proposed addendum for joint review, not an approved v0.5 specification. AC-18 through AC-21 remain PROPOSED until their unresolved decisions are reviewed against the v0.4 entities, event relationships, and related draft documents.

No change to the status or content of MEE-IAM-DATA-001 v0.4 is made or implied. The uploaded v0.1 through v0.4 documents are review sources; this addendum does not rewrite those historical versions.

---

AC-18 — Deterministic Event Ordering and Sequence Integrity

Objective:
Ensure that events can be ordered and reconstructed deterministically, including when multiple events share the same timestamp or originate from different event-specific records.

Requirements

1. Every material event MUST have one stable, unique "domain_event_id" shared by its "domain_event_envelopes" row, its event-specific row, and its required Audit Event.
2. The authoritative ordering fields MUST be stored on the event-specific row: "event_stream_type", "event_stream_id", and "event_sequence". The stream is the aggregate whose reducer consumes the event. For ordinary entity histories it is that entity's aggregate; for identity mapping lifecycle and migration events it is the external-identity aggregate identified by "external_identity_id".
3. "event_sequence" MUST increase monotonically and be unique within the identified stream. The reducer MUST define the stream membership and sequence allocation; equal sequence values within one stream are an integrity error.
4. "domain_event_envelopes" MUST remain shared event-identity, temporal, and correction metadata. It MUST NOT be treated as the authoritative location for an ordering sequence. "audit_events.event_sequence", where present, is local to the Audit stream and MUST NOT replace the domain event's aggregate sequence.
5. Within one stream, events MUST be replayed by "effective_at_utc", then by "event_sequence" for equal effective times. Timestamp alone MUST NOT determine order.
6. Sequence values from different streams MUST NOT be compared to infer causal order or resolve conflicting state. A cross-stream presentation order, if needed, is display-only and MUST be explicitly labeled as such.
7. Event-specific rows MUST link to their event envelope by the same "domain_event_id"; they MUST NOT supply an independent sequence that is treated as globally comparable.
8. Reconstruction using the same accepted event set, stream membership, and ordering rules MUST produce the same logical result.

Logical Test Cases

- TC-18.1: Given two events in the same stream with different "event_sequence" values, when reconstructed, they MUST follow effective-time order and then ascending sequence for a tie.
- TC-18.2: Given two events in the same stream with the same "effective_at_utc", replay MUST order them by "event_sequence".
- TC-18.3: Given two events in the same stream with duplicate "event_sequence" values, the affected stream MUST fail logical integrity validation.
- TC-18.4: Given two events in different streams, the system MUST NOT compare their sequence values to infer causal order or resolve state.
- TC-18.5: Given an event envelope or event-specific row without the required shared "domain_event_id" or event-specific ordering fields, the record MUST fail logical integrity validation.
- TC-18.6: Given an Audit Event with a local sequence different from the event-specific row's sequence, the system MUST use the event-specific row's sequence for domain replay.
- TC-18.7: Given the same accepted event set and stream membership, repeated reconstruction MUST produce identical logical ordering.

Expected Result:
Event ordering is explicit, deterministic, reproducible, and independent of ambiguous timestamp-only assumptions.

Decision status:
Selected design decision for this proposal: ordering is aggregate-stream-scoped; the event-specific row is authoritative for "event_stream_type", "event_stream_id", and "event_sequence"; the envelope is not. This follows v0.4's rule that sequence is unique within an event stream, its per-event-specific-table sequence fields, and its requirement that each reducer declare sequence scope and tie-breaking behavior (v0.4 §§3, 5.1–5.5, 5.6). The specific stream identity is made explicit here because v0.4 does not define it as a stored field. Identity lifecycle events share one external-identity stream so AC-21 handoffs have one replay order. This decision is proposed for joint confirmation; it does not change v0.4 or approve v0.5.

---

AC-19 — Correction Chain Integrity and Deterministic Resolution

Objective:
Ensure that corrections, reversals, and superseding events preserve historical records while producing an unambiguous effective history.

Requirements

1. Correction operations MUST be append-only and MUST NOT physically overwrite or delete the original event.
2. Each correction MUST identify:
   - Its own "domain_event_id"
   - The target event or record
   - The correction type ("RESTATE", "REVERSE", or "SUPERSEDE")
   - The applicable entity or aggregate scope
   - The reason and recorded timestamp
3. A correction MUST reference an existing, valid target within the permitted correction scope.
4. A correction MUST NOT target itself.
5. A correction chain MUST NOT contain cycles.
6. Multiple corrections that can affect the same effective state MUST be checked for conflicting branches using the target entity's declared reducer.
7. If correction branches conflict, the system MUST record and audit the conflict, mark the affected effective projection "UNRESOLVED", and MUST NOT present a value from either branch as authoritative. No branch wins by insertion order, latest timestamp, or sequence alone.
8. A conflict MAY be cleared only by a new, append-only, authorized correction-resolution event that references every competing branch head and states whether the branches are rejected, selected, or composed under the reducer's declared semantics. The resolution event MUST have its own event identity and sequence in the applicable stream; it MUST NOT edit or delete the original event or branch.
9. Correction effects MUST be defined for each supported event type and reducer. The reducer MUST distinguish an unresolved conflict from a resolved effective value.
10. Corrections MUST NOT silently alter unrelated entities, Gate instances, submissions, or authorization decisions.
11. "T_known" reconstruction MUST preserve what was recorded and known at the requested historical point, including any then-known unresolved conflict.
12. "T_effective" reconstruction MUST apply only resolved, authorized corrections according to the documented correction rules before replaying effective events.
13. An invalid, cyclic, out-of-scope, or unresolved conflicting correction MUST be identifiable as an integrity issue and MUST NOT silently produce an authoritative effective state.

Logical Test Cases

- TC-19.1: Given an original event and a valid "RESTATE" event, when querying "T_known" before the correction was recorded, the original historical knowledge MUST remain unchanged.
- TC-19.2: Given an original event and a valid correction, when querying "T_effective", the result MUST follow the defined correction semantics.
- TC-19.3: Given two individually valid corrections to the same target whose effects conflict, the system MUST retain and audit both, mark the affected projection "UNRESOLVED", and MUST NOT select a winner based on insertion time, timestamp, or sequence.
- TC-19.4: Given a correction that creates a cycle, the correction MUST fail logical integrity validation.
- TC-19.5: Given a correction targeting an event outside its permitted scope, the correction MUST fail logical integrity validation.
- TC-19.6: Given a correction referencing a nonexistent target, the correction MUST fail logical integrity validation.
- TC-19.7: Given a valid correction chain, repeated "T_effective" reconstruction MUST produce the same logical result.
- TC-19.8: Given a correction to one entity, unrelated entity histories MUST remain unchanged unless an explicit dependency is defined.
- TC-19.9: Given an unresolved conflicting branch, "T_known" MUST show that the conflict was known at that time and "T_effective" MUST NOT return an authoritative value for the affected projection.
- TC-19.10: Given a valid authorized resolution event that references all conflicting branch heads, "T_effective" MUST follow its explicit disposition; the original branches MUST remain available in history.

Expected Result:
Historical knowledge remains preserved; non-conflicting corrections replay deterministically; conflicting branches remain auditable and non-authoritative until explicitly resolved.

Decision status:
Selected design decision for this proposal: conflicting correction branches fail closed. They remain recorded and auditable, but the affected effective projection is explicitly unresolved until a new authorized, append-only resolution event references all competing branch heads and defines their disposition. No last-write-wins or timestamp/sequence winner is used. This extends v0.4's append-only correction metadata, explicit correction actions, and reducer-defined semantics (v0.4 §5.6) without rewriting its historical rules. This decision is proposed for joint confirmation; it does not change v0.4 or approve v0.5.

---

AC-20 — Authority Check Version and Scope Consistency

Objective:
Ensure that every authorization decision and sign-off is evaluated against a consistent set of identity, role, permission, assignment, and policy versions applicable at the exact decision time.

Requirements

1. Every "Authority Check" MUST identify the exact:
   - Principal
   - Submission
   - Gate instance
   - Approval scope and action
   - Evaluation timestamp
   - Role Assignment and applicable lifecycle event
   - Role Definition Version
   - Permission Rule and Permission Definition Version
   - Approval Assignment and applicable lifecycle event
   - The exact immutable "gate_definition_version_id" and "policy_definition_version_id" used for the decision, with retained or immutably retrievable definition content and its content digest. The current v0.4 model does not define these versioned entities; this is an explicit model gap, not an existing field-level guarantee.
2. The Role Assignment MUST be associated with the same Principal and Role Definition Version evaluated by the Authority Check.
3. The Role Code recorded in the authorization decision MUST resolve to the exact Role Definition Version used for evaluation.
4. The Permission Rule MUST resolve to the exact Permission Definition Version used for evaluation.
5. The Permission Rule MUST authorize the exact action and scope requested; a general permission MUST NOT be assumed to authorize a narrower or different scope without an explicit rule.
6. The Approval Assignment MUST be effective for the exact Gate instance and approval scope at the evaluation time.
7. The Principal, Role Assignment, Permission Rule, and Approval Assignment MUST all satisfy their applicable lifecycle and effective-time conditions.
8. The Authority Check MUST record each required condition as an explicit result, including "ALLOW" or "DENY" where applicable.
9. Overall "ALLOW" MUST be possible only when every mandatory authorization condition is satisfied.
10. The sign-off MUST reference the same Principal, submission, Gate instance, scope, and applicable policy/version basis as its successful Authority Check.
11. "evaluated_at_utc" MUST equal the sign-off's "occurred_at_utc", consistent with the v0.4 temporal rule. "recorded_at_utc" MUST remain separately preserved and MUST NOT be substituted for either decision-time value.
12. A later change to a Role Definition, Permission Definition, or Assignment MUST NOT retroactively change the historical authorization result.
13. A denied Authority Check MUST remain auditable even when no sign-off is created.
14. Submitter and approver MUST remain distinct for the same submission, consistent with the minimum Separation of Duties requirement.
15. The exact Gate-definition and policy-definition versions MUST be selected as effective at "evaluated_at_utc"; missing, ambiguous, mutable, or non-retrievable versions MUST prevent an "ALLOW".
16. A mutable "policy_version" label alone MUST NOT establish the authority basis. The Authority Check and Sign-off MUST reference the same immutable Gate and policy versions, and the selected versions MUST remain retrievable for historical verification.

Logical Test Cases

- TC-20.1: Given an active Principal but an expired Role Assignment, the Authority Check MUST return "DENY".
- TC-20.2: Given a valid Role Assignment referencing a different Role Definition Version from the one evaluated, the Authority Check MUST fail consistency validation.
- TC-20.3: Given a Permission Rule that does not authorize the requested action or scope, the Authority Check MUST return "DENY".
- TC-20.4: Given an Approval Assignment that is not effective for the requested Gate instance, the Authority Check MUST return "DENY".
- TC-20.5: Given an Authority Check with overall "ALLOW", when a sign-off references a different Principal, submission, Gate, or scope, the sign-off MUST fail logical integrity validation.
- TC-20.6: Given a successful historical Authority Check, when a Role or Permission Definition is changed later, the historical result MUST remain unchanged.
- TC-20.7: Given a denied Authority Check without a sign-off, the denial MUST remain retrievable through the audit history.
- TC-20.8: Given a submitter attempting to approve the same submission, the authorization decision MUST be "DENY".
- TC-20.9: Given a sign-off timestamp that violates the defined temporal consistency rule, the sign-off MUST fail logical integrity validation.
- TC-20.10: Given a mutable policy label without an immutable policy-definition reference and retained content, the Authority Check MUST NOT return "ALLOW".
- TC-20.11: Given an Authority Check or Sign-off that references a Gate-definition or policy-definition version different from the version effective at signing, it MUST fail logical integrity validation.
- TC-20.12: Given a missing, ambiguous, or unavailable immutable Gate-definition or policy-definition version at signing, the Authority Check MUST NOT return "ALLOW".
- TC-20.13: Given a later policy or Gate-definition revision, historical verification MUST retrieve and validate the exact versions and content digests captured by the Authority Check and Sign-off.

Expected Result:
Every sign-off is traceable to one consistent, time-valid authorization decision and its exact definition versions.

Decision status:
Selected design decision for this proposal: the signing-time authority basis is the exact immutable Gate-definition version and policy-definition version effective at the Authority Check's evaluation time, identified by stable version IDs and retained content (or immutable references) with content digests. Those same IDs and digests are captured in the Authority Check and referenced by the Sign-off; the existing mutable "policy_version" label is descriptive only and cannot be the sole basis. This closes an explicit v0.4 model gap: v0.4 retains role/permission definition versions and a policy label, but has no immutable Gate-definition or policy-definition version entities (v0.4 §§5.4–5.5). If either exact basis cannot be established, the check cannot ALLOW. This decision is proposed for joint confirmation; it does not change v0.4 or approve v0.5.

---

AC-21 — Identity Mapping Temporal Uniqueness and Migration Integrity

Objective:
Prevent ambiguous identity resolution and ensure that identity migration preserves historical attribution without creating overlapping active bindings.

Requirements

1. The external identity key MUST remain uniquely identifiable by the normalized issuer and exact external subject:
   - "issuer_normalized"
   - "subject"
2. Normalization MUST NOT modify or replace the original external subject value.
3. An external identity MUST NOT be actively bound to multiple Principals at the same effective time.
4. A Principal MUST NOT receive overlapping active bindings for the same external identity key.
5. The logical active interval for each mapping, derived from its accepted lifecycle events, MUST use the half-open convention "[effective_start, effective_end)": the start is inclusive and the end is exclusive. A null end means no accepted end event; these are derived boundaries, not mutable mapping-row fields.
6. An authorized migration at time "T" MUST end the prior mapping at "T" and start the successor mapping at "T". Both lifecycle events MUST reference the same "identity_migration_id" and form one logically atomic handoff; exactly one mapping is active at "T", with no gap or overlap.
7. The prior and successor mapping lifecycle events MUST use the same external-identity event stream ("event_stream_type" = "EXTERNAL_IDENTITY", "event_stream_id" = "external_identity_id") and distinct monotonically increasing "event_sequence" values as required by AC-18. At equal effective time, that sequence controls replay within the identity stream; the half-open interval remains the rule for whether a mapping is active.
8. Identity mapping creation, suspension, revocation, and migration MUST be represented through append-only events.
9. Identity migration MUST require an explicit "identity_migration_authorization" with a recorded decision.
10. A migration MUST proceed only when its linked authorization result is "ALLOW".
11. The migration authorization MUST identify:
   - Prior Principal
   - Proposed Principal
   - Exact external identity
   - Requested migration scope
   - Applicable policy version
   - Authority Check references
   - Decision and decision timestamp
12. A migration MUST preserve the prior mapping and its historical validity interval.
13. The new mapping MUST NOT become effective in a way that creates overlapping active bindings for the same external identity.
14. A denied, unresolved, or conflicting migration authorization MUST NOT create an active migrated identity mapping.
15. Later corrections to identity mapping history MUST follow the correction integrity rules in AC-19; an unresolved correction conflict MUST make the affected effective identity resolution non-authoritative.
16. Linking or migrating an external identity MUST NOT automatically create, grant, or transfer a Role Assignment.
17. Historical identity resolution MUST distinguish the Principal known at a historical point from the Principal resolved under the currently accepted effective history.

Logical Test Cases

- TC-21.1: Given the same normalized issuer and exact subject, when an active mapping already exists for Principal A, an overlapping active mapping to Principal B MUST fail logical integrity validation.
- TC-21.2: Given a mapping interval "[start, end)", the mapping MUST be active at "start" and inactive at "end".
- TC-21.3: Given a migration authorization with "DENY", the system MUST NOT create an active mapping to the proposed Principal.
- TC-21.4: Given a migration authorization with "ALLOW", when all required checks pass, the new mapping MAY become effective according to the authorized migration interval.
- TC-21.5: Given an authorized migration at "T", the prior mapping MUST be inactive and the successor mapping MUST be active at "T"; any interval gap or overlap MUST fail logical integrity validation.
- TC-21.6: Given a migrated identity, the prior mapping MUST remain available for historical reconstruction.
- TC-21.7: Given an identity migration, no Role Assignment MUST be created or transferred solely as a consequence of the identity migration.
- TC-21.8: Given a historical query before migration, identity resolution MUST return the historically applicable Principal.
- TC-21.9: Given a correction to an identity mapping event, the historical "T_known" result MUST remain unchanged while "T_effective" follows the accepted correction rules.
- TC-21.10: Given prior and successor mapping events at the same effective time, both MUST belong to the same external-identity stream and replay by distinct AC-18 sequence values; the active mapping at the handoff MUST be determined by the half-open interval, not by a cross-stream comparison.
- TC-21.11: Given conflicting corrections to a migration or either handoff event, the effective identity resolution MUST be marked "UNRESOLVED" and MUST NOT be returned as authoritative until an AC-19-compliant authorized resolution is recorded.

Expected Result:
Identity resolution remains unique at each effective time, migration is explicitly authorized, and historical Principal attribution remains reconstructable.

Decision status:
Selected design decision for this proposal: identity validity is half-open "[effective_start, effective_end)"; at migration time "T", the prior mapping ends and its successor begins in one authorized atomic handoff. AC-18 supplies the shared external-identity stream and its event-specific sequence to replay the same-time lifecycle events; the interval rule itself ensures exactly one mapping is active at "T". This makes explicit the boundary missing from v0.4's no-overlap and authorized-migration requirements (v0.4 §§5.5.1, 5.6). Conflicting corrections follow AC-19 and cannot yield an authoritative Principal until resolved. This decision is proposed for joint confirmation; it does not change v0.4 or approve v0.5.

---

Cross-Document Alignment and Proposed Decisions for Joint Confirmation

| Topic | Existing v0.4 basis | Decision for proposed v0.5 and rationale |
| --- | --- | --- |
| AC-18 — ordering | "domain_event_envelopes" supplies shared event identity and temporal metadata; event-specific tables have sequence fields; temporal reconstruction orders by effective time and immutable sequence. | Decision: aggregate-stream scope, explicitly identified on the event-specific row by "event_stream_type", "event_stream_id", and authoritative "event_sequence"; order same-stream ties by sequence. Envelopes and Audit-local sequence are not domain ordering authorities; sequences across streams are incomparable. |
| AC-19 — corrections | "correction_of_domain_event_id" and "correction_action" preserve the original event; supported actions are "RESTATE", "REVERSE", and "SUPERSEDE". | Decision: conflicting branches remain audited and fail closed as "UNRESOLVED"; only a new authorized append-only resolution event referencing all branch heads may restore an authoritative projection. No insertion-time or latest-timestamp winner. |
| AC-20 — authority basis | "signoff_authority_checks" references role/permission definition versions, lifecycle events, scope, results, and "policy_version". "sign_off_events" references the successful check. | Decision: record immutable Gate-definition and policy-definition version IDs plus retained content/immutable references and digests at evaluation/signing time; the same basis must be referenced by the Sign-off. The mutable policy label alone is insufficient; a missing or ambiguous version cannot ALLOW. |
| AC-21 — identity transition | "identity_mappings", "identity_mapping_events", "identity_migration_authorizations", and "identity_migrations" preserve mapping history and require explicit migration authorization. | Decision: use half-open "[start, end)" intervals; at handoff T, prior ends and successor starts atomically. Both use the shared external-identity stream and AC-18 sequence. An unresolved AC-19 correction conflict makes effective identity resolution non-authoritative. |
| Identity key terminology | v0.4 and CLERK-IDENTITY-CONFIG-001 v0.1 use normalized issuer plus exact subject; v0.4 treats "provider_label" as descriptive. | MEE-IAM-INT-001 v0.1 describes uniqueness as "(provider, issuer, subject)". Reconcile that wording with the v0.4 canonical key "(issuer_normalized, subject)" before approving the integration specification; do not change the Clerk subject value or use email as a key. |
| Architecture and implementation status | MEE-IAM-ARCH-001 v0.1 and MEE-IAM-INT-001 v0.1 are drafts pending review. The Clerk record says integration and principal mapping are not implemented or verified. | These documents do not establish implementation, successful Clerk integration, or approval. Their statuses and boundaries remain unchanged by this addendum. |

Identity interval decision for proposed v0.5 (approval pending):

- Derive each mapping's active effective interval from accepted lifecycle events using the half-open rule "[effective_start, effective_end)": the start is inclusive and the end is exclusive.
- For an authorized migration at time "T", atomically end the prior mapping at "T" and start the successor mapping at "T"; exactly the successor is active at "T".
- Put both mapping lifecycle events in the same external-identity stream identified by "external_identity_id", and order their same-time replay by the event-specific AC-18 "event_sequence".
- Preserve "recorded_at_utc" separately from effective time so "T_known" and "T_effective" queries remain distinguishable.
- Rationale: half-open intervals eliminate the shared-boundary double-active case, and one identity stream makes same-time lifecycle ordering deterministic without comparing local sequence values across streams. This is a proposed design decision, not a jointly approved change to v0.4 or an approval of v0.5.

Diagram alignment note:

The revised [MeeChain Evidence-to-Audit conceptual review aid](MEE-IAM-DATA-001-v0.4-Evidence-to-Audit-conceptual-review-aid.png) is not a complete ERD and is not evidence of implementation. Its labels map to the v0.4 model as follows:

| Diagram label | v0.4 logical model interpretation |
| --- | --- |
| Evidence | Canonical "evidence" record and its integrity history. The revised diagram uses the v0.4 fields "captured_at_utc" and "recorded_at_utc", not "created_at_utc". |
| Gate Snapshot | A "gate_status_events" decision event and its immutable "gate_event_document_refs", "gate_event_evidence_refs", and "gate_event_issue_refs", joined by "gate_event_id" and exact source-event references. It is not one generic snapshot row. |
| Authority Check | "signoff_authority_checks", including its exact submission, Principal, authority inputs, decision, and "domain_event_id". |
| Sign-off | "sign_off_events", linked to the exact successful Authority Check and matching Gate, submission, Principal, scope, and decision time. |
| Audit History | "audit_events", with the same "domain_event_id" as the corresponding material event-specific record. |

"domain_event_id" is the required one-to-one event-to-audit linkage for each material Domain Event; it is not a single universal join key that collapses Evidence, Gate Snapshot, Authority Check, and Sign-off into one record. Their cross-stage relationships use the specific IDs and constraints in v0.4. The revised diagram retains this caveat wherever it is presented.

---

Acceptance Criteria Status

| AC | Subject | Status |
| --- | --- | --- |
| AC-18 | Deterministic Event Ordering | PROPOSED |
| AC-19 | Correction Chain Integrity | PROPOSED |
| AC-20 | Authority Check Version and Scope Consistency | PROPOSED |
| AC-21 | Identity Mapping Temporal Uniqueness | PROPOSED |

Review Status: PENDING CROSS-DOCUMENT REVIEW
Implementation Status: NOT ASSESSED
Test Execution Status: NOT EXECUTED
Approval Status: NOT APPROVED

Scope and Approval Boundary

These acceptance criteria define logical data-model requirements and testable expected outcomes only.

They do not authorize or imply:

- Database schema creation or migration
- Evidence import or modification
- Clerk integration or identity synchronization
- Role or permission assignment
- Notion synchronization
- Application implementation or deployment
- VM, QBFT, Besu, HSM, or validator operations
- Genesis or validator key generation
- Gate approval or runtime authorization

Document Control: This addendum is a proposed revision for consideration in MEE-IAM-DATA-001 v0.5. It does not modify or supersede the immutable v0.4 review draft. Acceptance of AC-18 to AC-21 requires explicit document review and approval.