# MEE-IAM-INT-001 — Integration Specification

| Field | Value |
|---|---|
| Document ID | MEE-IAM-INT-001 |
| Version | 0.2 |
| Status | DRAFT — PENDING REVIEW |
| Date | 2026-11-05 |
| Scope | Proposed Clerk, Notion, and Replit integration boundaries for the MeeChain QBFT Evidence Registry |
| Related documents | MEE-IAM-DATA-001 v0.4 (DRAFT — PENDING REVIEW); CLERK-IDENTITY-CONFIG-001 v0.1 (DRAFT — PENDING REVIEW); MEE-IAM-ARCH-001 is not present or issued |

> This is a design proposal only. It does not configure or connect services, request or store credentials, implement APIs, create principals or roles, change Runtime behavior, or authorize tests or operational actions. Its contracts are provisional until the Data Model and Architecture Specifications have been reviewed.

## 1. Purpose

Define the identity, authorization, API, document-reference, error, and audit boundaries for future integrations. The design keeps authentication separate from application authorization and keeps both separate from evidence review, Gate decisions, and Runtime operations.

## 2. Status, dependencies, and scope

MEE-IAM-DATA-001 v0.4 and CLERK-IDENTITY-CONFIG-001 v0.1 are marked `DRAFT — PENDING REVIEW`; the referenced Architecture Specification, MEE-IAM-ARCH-001, was not found and is not issued. This revision aligns the proposed identity-key wording with the logical identity model in Data Model v0.4 and the target flow in the Clerk identity record. It does not approve those documents, establish implementation, or resolve other review decisions. The entity names and API contracts remain proposals to reconcile during review.

### In scope

- Clerk as an external authentication provider, with MeeChain-owned principal mapping and authorization.
- Proposed identity lifecycle rules for linking, unlinking, recovery, and provider-subject migration.
- Proposed API contracts for authenticated identity, Registry access, and authorized changes.
- Notion as a source of document references and explicitly approved display metadata only.
- Replit as the development and application-serving platform, not as the authority for MeeChain identities, roles, approvals, or Runtime actions.
- Denial behavior, integration errors, and audit requirements.

### Out of scope

- Connecting/configuring Clerk, Notion, or Replit; creating credentials, secrets, webhooks, or provider applications.
- API implementation, database schema, token/session configuration, deployment topology, and provider-specific endpoint choices.
- Final role catalogue, role-granting policy, and service-account issuance process.
- Runtime control APIs, operational permissions, test execution, or approval to start a Node.

## 3. Authority boundaries

| Concern | Authority | Non-authoritative inputs |
|---|---|---|
| Authentication | Clerk establishes an external authenticated subject. The MeeChain API must independently validate the presented authentication proof before accepting it. | Browser-supplied profile fields, unverified claims, email address, and Notion/Replit account state. |
| Internal identity | MeeChain maps the validated `(issuer_normalized, subject)` pair to an opaque internal `principal_id`. The subject is retained exactly as issued. | Clerk subject as a database primary key; matching by email; a Notion or Replit user ID. |
| Application authorization | MeeChain evaluates the internal principal's lifecycle state, current scoped role assignments, requested action, and applicable policy. | Signup, Clerk metadata, frontend controls, Notion properties, Replit project roles, evidence status, or a prior Gate decision. |
| Document references | MeeChain records an external Notion page reference and any reviewed allowlisted metadata. | Notion page text, tags, permissions, or status fields as proof of review or approval. |
| Platform operations | Replit provides development and application-serving capabilities under its platform controls. | Replit workspace membership or deployment state as MeeChain authorization or operational approval. |
| Operational authorization | Not defined by this integration specification. It requires a separate, explicit policy and authorization design. | Authentication success, document approval, Gate status, or API access alone. |

## 4. Clerk identity mapping

### 4.1 Logical mapping

The logical model separates an external identity from its binding to an internal principal. The following is a logical contract consistent with the entities in MEE-IAM-DATA-001 v0.4, not a physical schema:

| Record | Attribute | Rule |
|---|---|---|
| External identity | `external_identity_id` | Opaque internal identifier for one external identity record. |
| External identity | `issuer_normalized` | Validated issuer normalized according to the issuer's documented rules after architecture review. |
| External identity | `subject` | Validated, provider-issued subject identifier, preserved exactly as issued. Do not lowercase or otherwise normalize it unless the issuer specification explicitly requires that transformation. |
| External identity | `provider_label` | Descriptive provider metadata, initially `clerk`; it is not part of the identity key or uniqueness constraint. |
| Identity mapping | `identity_mapping_id` | Opaque, stable identifier for a binding between one external identity record and one internal principal. |
| Identity mapping | `principal_id` | Opaque internal MeeChain principal identifier; never the external subject itself. |
| Identity mapping | `mapping_status` | Derived from append-only mapping lifecycle events; exact statuses and transitions remain subject to review. |
| Identity mapping | `created_at_utc`, `created_by` | Mapping creation time and the internal actor or controlled provisioning process responsible. |

The canonical external identity key is `(issuer_normalized, subject)`. That pair must identify at most one external identity record and must be unique on that record. The `subject` value is preserved exactly as issued. `provider_label` is descriptive metadata and does not extend or alter the key. An external identity is bound to an internal principal through an identity mapping; that binding must not be silently changed. At any instant, one external identity may have at most one effective active Principal binding.

### 4.2 First sign-in and role neutrality

1. The API accepts a Clerk identity only after validating the authentication proof server-side against the configured issuer and intended audience, including expiry and other required token checks defined during implementation review.
2. If a valid `(issuer_normalized, subject)` has no external identity record, mapping, prior lifecycle reservation, or unresolved identity case, a future, reviewed first-use provisioning flow may create an internal human principal, an external identity record, and its initial identity mapping. It must not create a role assignment.
3. If the key already has a mapping history but no active mapping, first-use provisioning must not silently create a new binding; the identity lifecycle and conflict rules in Section 4.4 apply.
4. The new principal has no application permissions beyond any explicitly approved, non-sensitive self-service operation. Until such a policy exists, access is denied by default.
5. Signup, successful authentication, verified email, profile metadata, organization membership, or a Clerk claim does not grant or imply a MeeChain role.
6. Role assignments are separate append-only records created only through a reviewed, authorized MeeChain process. The actor, scope, reason, and effective interval must be auditable.

Email addresses and display names may be used as optional display/contact attributes only after policy review. They are mutable and are not identity keys. Two accounts with the same email must not be auto-merged or auto-linked.

### 4.3 Mapping lifecycle and conflict handling

- A missing, suspended, revoked, superseded, ambiguous, or conflicting mapping fails closed; it does not fall back to email matching or a browser-provided principal ID.
- Account linking, unlinking, recovery, and provider-subject changes follow the policy in Section 4.4. These rules remain a proposal until explicitly approved; no such flow may be enabled before approval.
- Principal suspension/deactivation and role revocation are MeeChain state changes. Ending a Clerk session alone does not prove that MeeChain roles have been revoked.
- A duplicate `(issuer_normalized, subject)` key, duplicate mapping, or attempted reassignment returns a conflict and creates a security audit event; it is not repaired by overwriting the existing association.
- A change of Principal for an existing external identity requires the explicit identity-migration authorization and record described in MEE-IAM-DATA-001 v0.4. This integration draft does not authorize such a migration.

### 4.4 Identity linking, unlinking, recovery, and subject migration

The following is the proposed lifecycle policy for review. It is not active authorization to enable these flows. Explicit policy approval, approved proofing methods, and implementation review are prerequisites to enabling any linking, unlinking, assisted recovery, or subject-change operation.

#### Common proofing and authority rules

- Email address, even when provider-verified, is never an identity key and is not sufficient proof to link, unlink, recover, or migrate an identity. Email may be used to notify an affected user, but not to approve the action.
- The service must validate all provider proofs server-side. A fresh step-up authentication is required in the same bounded, transaction-bound flow; the implementation review must set the accepted factors and maximum challenge lifetime. A stale application session, browser-supplied profile, recovery email, or client-supplied subject is not proof.
- Self-service lifecycle actions may be initiated only for the authenticated user's active MeeChain principal. They cannot select or supply a target `principal_id`.
- Assisted recovery or conflict correction requires two distinct, specifically authorized identity-recovery reviewers acting independently. Their narrowly scoped duty must be explicitly assigned through a separately approved governance process; neither a Clerk account nor a broad administrator role alone confers this authority. Neither reviewer may be the requester, the subject of the case, or an actor whose role-grant decision is being recovered. These reviewers may decide identity ownership and mapping status only; they cannot grant roles or approve Registry or Runtime actions.
- Proofing methods must be approved before use and must establish control of the claimed identity independently of the email channel under recovery. For assisted recovery, reviewers must verify two independent proofing signals, including at least one established before the recovery incident. If the required proof cannot be obtained, deny the request and leave the mapping unchanged.
- A lifecycle mutation and its required audit event must commit atomically. If proof verification, policy, conflict checks, or required audit persistence is unavailable, fail closed.
- A change of Principal for an existing external identity is an identity migration under MEE-IAM-DATA-001 v0.4: it requires an `identity_migration_authorizations` record with an `ALLOW` decision followed by the corresponding `identity_migrations` record. The authorization must match the exact external identity and prior mapping. This is distinct from a Gate approval and is not granted by linking, recovery, or Gate passage. The authorization policy and eligible approvers remain pending review.

#### Linking an identity

- Self-service linking requires fresh strong re-authentication to an already-active mapped subject and a separately validated authentication proof for the new subject, bound to the same linking transaction.
- The new `(issuer_normalized, subject)` key must not already identify an external identity that is mapped, reserved by a prior lifecycle event, or involved in an unresolved identity case. A different `provider_label` does not make an existing key new. Existing associations are never merged or reassigned as a side effect of linking.
- On success, record the external identity and mapping, append the identity-mapping event and audit event, then notify the principal through existing verified channels. Notifications are informational and do not substitute for proofing.

#### Unlinking an identity

- Self-service unlinking requires fresh strong re-authentication to the identity being removed and proof of control of a different, active identity that will remain linked.
- The operation must not remove or disable the principal's last active authentication path. A request to remove the last path is not self-service; until a separate account-deactivation process is approved, deny it and leave the mapping unchanged.
- Record the revocation as an append-only event and notify the affected principal. Do not delete or reuse the external identity or mapping.

#### Account recovery

- A provider recovery event may restore access to an existing principal only when the server verifies the same previously mapped `(issuer_normalized, subject)` key and the user completes fresh step-up authentication with an approved, non-email-only factor. Recovery does not create, merge, or change an identity mapping.
- An email-only reset, email match, support request, or other weak recovery signal does not grant Registry access to the principal and does not authorize linking or reassignment. If the required step-up proof is unavailable, route the request to the assisted recovery process; otherwise deny it.
- Assisted recovery requires the two independent, authorized reviewers and proofing rules above. A successful decision may restore access to the existing principal only; if a replacement subject is needed, handle it as a new external identity key under the provider-subject change rules below. Any change of Principal for an existing external identity must use the explicit identity-migration authorization and record described above. Notify the principal through a previously verified channel not used for the recovery, where one is available; the notice is not proof of identity or authority. Neither action creates or modifies role assignments. A failed or unresolved decision leaves the mapping unchanged and keeps any disputed access restricted.

#### Provider-subject change

- A changed subject value creates a different `(issuer_normalized, subject)` key and therefore a distinct external identity; it is not an in-place update to the old external identity. Preserve the original subject and its history exactly as issued.
- If the same principal is moving to a new subject, treat the new subject as a separately proved and linked external identity, then retire the old mapping through an approved, append-only lifecycle event. The change must preserve both identity records and their histories, must not silently transfer a mapping, and must not leave the principal without an active authentication path.
- If the old subject cannot be proved, use the reviewed assisted-recovery process; do not use email matching as a substitute. If an existing external identity key is to be rebound from one Principal to another, treat that separately as an identity migration and require the explicit `ALLOW` authorization and `identity_migrations` record in MEE-IAM-DATA-001 v0.4.
- If either key is already mapped, reserved, ambiguous, or under dispute, fail with a safe conflict response and use the identity-conflict path below. A provider-label change alone is not a subject change and does not create a new identity.

#### Duplicate and conflicting identities

- Any duplicate, ambiguous, or conflicting mapping fails closed with a safe conflict response. Do not disclose another principal's details, auto-merge principals, overwrite or delete identity records or mappings, or resolve the conflict by comparing email addresses or provider labels.
- Open an identity-conflict case, block the requested lifecycle change, and restrict the disputed mapping or principal when compromise or ownership ambiguity warrants it. Two independent identity-recovery reviewers must examine the existing audit history and approved proofing evidence.
- If reviewers confirm a prior recording error, correct it only through an attributable, append-only correction that references the original event and is committed with its audit event. Do not alter history. If unique ownership cannot be established, leave the conflict unresolved and deny access to the disputed mapping; a separately provisioned principal, if permitted, remains role-neutral and is not merged with the disputed principal.

None of these actions creates, copies, or changes a MeeChain role. Role assignment remains a separate, reviewed, authorized, and audited process.

## 5. Authorization checks

Every protected API operation must enforce authorization on the server. The minimum decision sequence is:

1. Validate the Clerk authentication proof. Reject missing or invalid proof.
2. Resolve exactly one active internal identity mapping for the verified `(issuer_normalized, subject)` key. Reject if none, suspended, revoked, or conflicting.
3. Resolve the internal principal and reject inactive or suspended principals.
4. Identify the requested action and target scope from server-validated route and request data.
5. Evaluate current MeeChain role assignments for that principal, action, and scope, including validity interval, revocation state, and separation-of-duties rules.
6. Apply resource-state and transition rules. A role does not make an invalid state transition valid.
7. Record required audit data with the state change. If the required audit record cannot be committed with the change, do not apply the change.

Authorization is deny-by-default. The API must not trust role names or permissions supplied by the client or in Clerk public/private metadata. Read and write access must be checked independently and at the target resource's scope.

Document/evidence assessment, Gate sign-off, and operational authorization are distinct decisions. Even a valid approver role or a passed Gate does not authorize a Runtime action or test execution under this specification.

## 6. Proposed API contract

These logical API operations are intended for later OpenAPI review. They do not select a host, transport deployment, database, or provider API version. All paths and payloads are provisional and are not implemented by this document.

### 6.1 Common contract

- Protected requests require a valid server-verified Clerk authentication proof. Clients do not submit an authoritative `principal_id` or role.
- IDs are opaque references, not permissions. A client must be authorized for each target.
- Requests with a state-changing effect must be validated against the current state and policy. The API must not treat a replay as a second independent approval or sign-off.
- Responses must return only fields permitted for the caller. Do not expose provider tokens, secrets, or unrelated identity/profile data.
- Use UTC timestamps and a server-generated or safely propagated correlation ID. A caller-provided correlation ID is not an identity or authorization input.
- State-changing operations must support safe retry semantics, such as an idempotency key or a reviewed equivalent. Duplicate submissions must not create duplicate sign-offs, assignments, or audit effects.

### 6.2 Candidate operations

| Operation | Authentication and authorization | Contract intent |
|---|---|---|
| `GET /v1/me` | Valid Clerk proof and active identity mapping. | Return the caller's internal principal identifier and only the caller's currently effective, permitted role/scope summary. No role is created by reading this resource. |
| `GET /v1/document-versions/{documentVersionId}/references` | Valid mapping plus read permission for the requested document scope. | Return authorized document-to-evidence references and their contextual assessment view. Do not return protected evidence bytes or storage credentials. |
| `POST /v1/document-versions/{documentVersionId}/references` | Valid mapping plus a role authorized to create a reference in that scope. | Create a reference to an existing canonical Evidence ID; validate the document version and register-item version. Do not create or overwrite canonical evidence implicitly. |
| `POST /v1/document-evidence-references/{referenceId}/assessments` | Valid mapping plus assessment permission for the reference's scope; enforce separation of duties where required. | Append a contextual assessment event with decision and rationale. Do not overwrite earlier assessments or alter another document's assessment. |
| `POST /v1/gates/{gateInstanceId}/sign-offs` | Valid mapping plus explicit sign-off authority for that Gate and scope; enforce actor separation and current Gate state. | Append a scoped sign-off event. This operation does not start a test, authorize a Node, or invoke Runtime controls. |
| `POST /v1/role-assignments` | Restricted to a separately authorized role-administration process, with explicit target, role, scope, interval, reason, and actor. | Append a role grant only under a reviewed assignment policy. Signup and user self-service cannot call this to grant themselves a role. |

The eventual OpenAPI specification must settle request/response schemas, pagination, filtering, maximum sizes, concurrency handling, data minimization, and which role/scope may use each operation before implementation.

### 6.3 Prohibited API behavior

- No public or user-controlled operation may set arbitrary roles, principal status, actor identity, Gate status, or approval status.
- Signup, linking, unlinking, provider recovery, assisted recovery, and subject migration must not create, copy, or change a role assignment.
- No endpoint may accept a Notion property, Clerk metadata field, or Replit role as proof of a MeeChain decision.
- No API in this specification may start, stop, configure, or test a Node Runtime or HSM.
- No write endpoint may silently succeed if its required audit event fails.

## 7. Notion reference mapping

Notion is an optional document-reference surface. It is not the canonical Registry, identity provider, authorization service, evidence store, review authority, or Runtime approval system.

### 7.1 Allowlisted reference fields

The proposed mapping is deliberately limited:

| Field | Purpose and constraint |
|---|---|
| `provider` | Constant `notion`. |
| `notion_page_id` | Opaque Notion page identifier for locating the referenced page. |
| `notion_page_uri` | Canonical page URI for navigation; do not store temporary, signed, or credential-bearing URLs. |
| `document_id` | MeeChain document-family reference, when the page maps to a known family. |
| `document_version_id` | Exact immutable MeeChain version reference, when the page maps to a known version. |
| `display_title` | Optional, length-limited display value; not a trusted document identity. |
| `metadata_schema_version` | Version of the reviewed allowlist used to interpret optional metadata. |
| `reference_recorded_at_utc` | Time MeeChain recorded or refreshed this reference. |

Only fields explicitly approved in the reviewed metadata allowlist may be imported or projected. The initial proposal excludes Notion-authored approval, Gate, evidence-assessment, role, identity, Runtime, and authorization fields. If a future integration displays Registry status in Notion, it must be a clearly labeled, non-authoritative projection with an identifiable source and observation time; changes in Notion must not write back that status.

### 7.2 Notion safety rules

- A page title, body, checkbox, tag, database property, comment, or page permission is content/reference metadata only. None is an approval or authorization signal.
- Page content is untrusted input. Do not execute instructions embedded in it, use it as a policy source, or accept links as proof that an artifact was reviewed.
- A missing, stale, inaccessible, or deleted page reference does not alter MeeChain evidence, review, role, Gate, or Runtime state.
- The Registry stores a reference, not a copied Notion page or canonical evidence payload. Credentials and page contents are not audit payloads.
- Any future import/export direction, sync conflict policy, and provider authorization scope must be explicitly reviewed before connection.

## 8. Replit platform boundary

- Replit is the development and application-serving platform. Workspace membership, deployment permissions, and platform identity do not create a MeeChain principal, assign a MeeChain role, or approve a Gate or Runtime action.
- Application users authenticate through the reviewed Clerk flow; API authorization remains a MeeChain responsibility regardless of hosting platform.
- Development, test, and production environments must be treated as distinct trust boundaries. The environment, secret-handling, deployment, and service identity design is deferred to MEE-IAM-ARCH-001 and implementation review.
- If a future backend workload needs a service identity, it must be represented by a distinct internal service principal with narrowly scoped permissions and auditable issuance/revocation. A shared user account or workspace role is not a substitute.
- Provider credentials, if later approved, must use the platform's approved secret-management mechanism and must never be placed in source, client bundles, Notion, Registry records, API responses, or audit events. No credentials are requested or configured as part of this draft.
- A deployment or successful API response is not an approval to operate a Node, HSM, or test environment.

## 9. Error behavior

Errors must be stable, machine-readable, sanitized, and must not disclose tokens, secrets, provider internals, protected evidence, or unnecessary identity details. A future common error envelope should include a stable `code`, safe `message`, `correlation_id`, and optional field-level validation details.

| Condition | Proposed response | Required behavior |
|---|---|---|
| Missing, malformed, expired, wrong-issuer, or wrong-audience authentication proof | `401 UNAUTHENTICATED` | Do not resolve authorization from client data. Log a sanitized security event; never log the proof itself. |
| Authenticated subject has no mapping, or mapping/principal is inactive | `403 IDENTITY_NOT_AUTHORIZED` | Fail closed; do not fall back to email, auto-link, or create a role. |
| Active principal lacks required role or scope | `403 FORBIDDEN` | Do not perform the operation; record a denial event for security-relevant protected actions. |
| Resource absent or intentionally concealed from this caller | `404 NOT_FOUND` | Avoid revealing whether a protected resource exists where disclosure would be unsafe. |
| Duplicate `(issuer_normalized, subject)` key, conflicting active binding, stale version, or idempotency conflict | `409 CONFLICT` | Do not overwrite existing identity or state; return a safe conflict code. |
| Invalid payload or disallowed state transition | `400 INVALID_REQUEST` or `422 INVALID_TRANSITION` | Do not mutate state; return safe, actionable validation details. |
| Rate limit exceeded | `429 RATE_LIMITED` | Do not bypass authorization; include a safe retry hint where applicable. |
| Provider verification unavailable or required audit storage unavailable | `503 SERVICE_UNAVAILABLE` | Fail closed for protected reads/writes as applicable; never accept unverified identity or apply an unaudited mutation. |
| Unexpected internal failure | `500 INTERNAL_ERROR` | Return no stack trace or secrets; preserve a correlation ID for investigation. |

The final distinction between `400` and `422`, response envelope, retry policy, and disclosure behavior requires Architecture/API review.

## 10. Audit events and privacy

Material identity, authorization, and Registry state changes must use the append-only audit model proposed in MEE-IAM-DATA-001 v0.4. At minimum, record:

- principal provisioning and identity-mapping creation, suspension, revocation, or conflict;
- identity-link, unlink, recovery, subject-change, assisted-review, identity-conflict, and identity-migration authorization requests and outcomes, including denials and corrections;
- material authentication rejection and authorization denial, with sanitized reason codes;
- role assignment, revocation, and attempted unauthorized role changes;
- creation or correction of a Notion reference and changes to its allowlisted metadata;
- document-evidence reference creation/correction, evidence assessment, and Gate sign-off;
- state-change failure when a required audit write fails, where a separate security log can safely record that failure.

Each applicable event should include an internal actor or explicit system actor, action, target, decision/result, UTC time, reason or stable reason code, correlation ID, and relevant scope. Capture the actor's effective role/scope as an event-time snapshot only where required for later interpretation. Corrections append a new event referencing the prior event; they do not rewrite history.

For identity lifecycle attempts, also record the applicable principal/mapping reference, proofing method code, and each reviewer's decision as a separately attributable event under the same correlation ID. Record denials and unresolved conflicts. Do not include raw proofing evidence, provider claims, or email contents.

Never log Clerk tokens/session cookies, passwords, private keys, HSM credentials, secret values, full Notion page content, or unnecessary personal data. Avoid storing raw provider claims in general audit payloads. Access to security logs and retention are implementation decisions requiring review.

For a state mutation that requires an audit event, the state change and event must be committed together or not at all. If atomic persistence is not technically available, a reviewed alternative must provide equivalent fail-closed guarantees before implementation; silent partial success is not acceptable.

## 11. Review decisions and acceptance criteria

This draft is ready for review only; it does not certify that review has happened. Before implementation, reviewers must resolve at least:

1. MEE-IAM-DATA-001 and MEE-IAM-ARCH-001 status, entity names, API/service topology, and audit atomicity.
2. Final role catalogue, scopes, role grant/revocation authority, self-approval rules, and permissions for each proposed operation.
3. Explicit approval of the Section 4.4 identity lifecycle policy, including approved proofing factors, reviewer appointment/independence, challenge lifetime, notification, and unresolved-case handling.
4. Clerk issuer/audience/session validation requirements and safe handling of provider outages.
5. The exact Notion metadata allowlist, reference ownership, sync direction, and stale/deleted-reference behavior.
6. Replit environment separation, workload identity, secret-handling controls, and operational responsibility boundaries.
7. Final API schemas, error envelope, idempotency, rate limits, privacy/retention policy, and security logging.

Acceptance criteria for this specification:

- Clerk authenticates; MeeChain maps a validated `(issuer_normalized, subject)` pair to one external identity record and an opaque internal principal through an identity mapping; the subject is preserved exactly as issued.
- `provider_label` is descriptive metadata only and is not part of external identity uniqueness. The unique key is `(issuer_normalized, subject)`.
- Signup and first-use provisioning do not assign roles; external email/profile metadata is not a mapping key.
- Linking, unlinking, recovery, provider-subject change, and any change of Principal follow the proofing, authority, conflict-resolution, migration-authorization, and audit controls in Section 4.4; none grants roles.
- Notion holds only approved document references/metadata and cannot approve evidence, a Gate, a Runtime action, or a test.
- Replit access and deployment state do not imply MeeChain roles or approvals.
- Protected operations fail closed on invalid identity, missing authority, provider-verification failure, or required audit-write failure.
- Material identity, authorization, and Registry decisions have defined append-only audit coverage without recording secrets.
- No service was connected, credential requested, API implemented, or Runtime behavior changed in preparing this draft.

## 12. Revision history

| Version | Status | Summary |
|---|---|---|
| 0.2 | DRAFT — PENDING REVIEW | Draft revision based on MEE-IAM-INT-001 v0.1; aligns external identity uniqueness, exact subject handling, provider metadata, identity mapping, and migration terminology with MEE-IAM-DATA-001 v0.4 and CLERK-IDENTITY-CONFIG-001 v0.1. |
